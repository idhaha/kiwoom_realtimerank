# Tasks: 동적 탭 — 사용자 정의 차트 탭

**Input**: Design documents from `/specs/005-dynamic-tabs/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: 브라운필드 검증 작업. quickstart.md로 검증.

## Phase 1: Setup

- [ ] T001 `+` 메뉴 및 3가지 탭 유형 생성 UI가 정상 렌더링되는지 확인 — `public/index.html`, `public/app.js`

## Phase 2: Foundational

**⚠️ CRITICAL**

- [ ] T002 동적 탭 ID 생성 규칙(생성 시각 기반)과 `tabData[id]` 저장 구조(data-model.md DynamicTab)가 일치하는지 확인 — `public/app.js`
- [ ] T003 [P] 개별 데이터 소스 실패가 탭 전체에 영향을 주지 않는 격리 구조(FR-007)가 공통으로 적용되어 있는지 확인 — `public/app.js`
- [ ] T003a `fred_api.py`, `requirements.txt`가 프로젝트 루트에 존재하고 `pip install -r requirements.txt`로 의존성이 설치되어 있는지 확인 — 루트 디렉토리 (dev_tools로 이동 시 `/api/fred` 즉시 실패, docs/analysis-log.md 참고)

**Checkpoint**: 탭 생명주기/격리 공통 로직 검증 완료

---

## Phase 3: User Story 1 - 차트 그리드 탭 추가 (Priority: P1) 🎯 MVP

**Goal**: 차트 그리드 탭 추가 후 1초 이내 사용 가능, TradingView/Investing.com 전환 가능

**Independent Test**: `+` → `Dynamic 차트` 선택 시 기본 심볼 4종이 채워지는지 확인

### Implementation for User Story 1

- [ ] T004 [US1] 기본 심볼 4종(`FX_IDC:USDKRW`, `KRX:KOSPI`, `KRX:KOSDAQ`, `BINANCE:BTCUSDT`, FR-002)이 정확한지 확인 — `public/app.js`
- [ ] T005 [P] [US1] TradingView ↔ Investing.com 전환(FR-003)이 셀의 `mode`/`mainSrc`/`subSrc`(data-model.md GridCell)에 정확히 반영되는지 확인 — `public/app.js`
- [ ] T006 [US1] 심볼 입력 후 [이동] 클릭 시 `getDirectTradingViewUrl` 임베드 갱신을 확인 — `public/app.js`
- [ ] T007 [US1] 새 탭이 생성 직후 활성화되고 저장되는지(FR-005) 확인 — `public/app.js`
- [ ] T008 [US1] T004~T007 불일치 수정 — `public/app.js`
- [ ] T009 [US1] quickstart.md 시나리오 1~3 실행 후 SC-001 확인

**Checkpoint**: User Story 1 독립적으로 동작

---

## Phase 4: User Story 2 - 해외종목/환율·금리 커스텀 탭 (Priority: P2)

**Goal**: 사용자 정의 문법으로 여러 데이터 소스를 구획별로 렌더링

### Implementation for User Story 2

- [ ] T010 [US2] `parseCustomCharts` 문법 파싱(구획, 쌍/삼중항 판별)이 spec.md의 문법 예시대로 동작하는지 확인 — `public/app.js`
- [ ] T011 [P] [US2] Finviz/TradingEconomics/FRED/ECOS 프록시(FR-004, contracts/api.md)가 정상 응답하는지 확인 — `server.js`
- [ ] T012 [US2] 개별 항목 실패 시 나머지 항목이 정상 로드되는지(FR-007) 확인 — `public/app.js`
- [ ] T013 [US2] 빈 설정 시 "등록된 차트가 없습니다" 안내가 표시되는지 확인 — `public/app.js`
- [ ] T014 [US2] T010~T013 불일치 수정 — `server.js`, `public/app.js`
- [ ] T015 [US2] quickstart.md 시나리오 4~5 실행 후 SC-002, SC-003 확인

**Checkpoint**: User Story 1, 2 모두 독립적으로 동작

---

## Phase 5: User Story 3 - 동적 탭 관리 (Priority: P3)

**Goal**: 드래그 순서 변경, 더블클릭 이름 변경, 우클릭 삭제가 정상 동작

### Implementation for User Story 3

- [ ] T016 [US3] 드래그 순서 변경 결과가 저장되는지(FR-006) 확인 — `public/app.js`
- [ ] T017 [US3] 더블클릭 이름 변경 및 고정 탭 제외 처리(FR-006)를 확인 — `public/app.js`
- [ ] T018 [US3] 우클릭 삭제 확인 대화상자 및 데이터 정리(FR-006)를 확인 — `public/app.js`
- [ ] T019 [US3] T016~T018 불일치 수정 — `public/app.js`
- [ ] T020 [US3] quickstart.md 시나리오 6 실행

**Checkpoint**: 3개 User Story 모두 독립적으로 동작

---

## Phase 6: Polish & Cross-Cutting Concerns

- [ ] T021 [P] 캡처 모드 중 동적 탭 로드/새로고침 억제(FR-009) 확인 — `public/app.js`
- [ ] T022 같은 탭 내 캔버스 차트 간 커서/줌 동기화 범위(FR-008)가 외부 iframe까지 확장되지 않음을 확인 — `public/app.js`
- [ ] T023 quickstart.md 전체 시나리오 최종 실행

## Dependencies & Execution Order

- Setup → Foundational → US1 → US2(US1과 독립적) → US3(탭 존재 전제, US1/US2 완료 후 검증 권장) → Polish

## Notes

- 커스텀 문법 파서는 휴리스틱 기반임을 검증 시 전제하고, "의도와 다르게 해석되는" 사례는 버그가 아니라 문서화된 한계(Assumptions)로 분류한다.

---

## Verification Log — 2026-09-30

> 원칙: 이번 단계에서는 코드 수정 없이 현재 구현을 검증했습니다. 브라우저에서만 확인 가능한 항목은 `⏳`로 남겼습니다.

| Task | 결과 | 검증 내용 |
|---|---|---|
| T001 | 🔴 | `+` 메뉴는 `Static 차트`와 `Dynamic 차트` 2개만 제공됩니다. spec의 3가지 동적 탭 유형 중 `exchange_rate` 전용 생성 메뉴는 확인되지 않았습니다. |
| T002 | 🔴 | ID 자체는 `Date.now()` 기반(`tab_custom_...`, `tab_grid_...`, import 시 `Date.now()+random`)이지만, `tabData[id]` 구조가 일관된 `DynamicTab` 객체가 아닙니다. Dynamic 차트는 `tabData[id]`에 배열을 저장합니다. data-model의 `id/name/type/config` 구조와 불일치합니다. |
| T003 | 🟢 | 이미지 로드는 `onerror`에서 해당 항목만 완료 처리하고, 다중 시리즈도 항목별 로드/예외 처리가 존재하여 개별 실패가 전체 로드를 중단하지 않는 구조입니다. |
| T003a | ⏳ | 현재 제공된 파일 집합에서는 프로젝트 루트의 `fred_api.py`와 `requirements.txt` 실재 여부 및 `pip install -r requirements.txt` 실행 결과를 검증할 근거가 없습니다. |
| T004 | 🟢 | 기본 심볼 4종은 `FX_IDC:USDKRW`, `KRX:KOSPI`, `KRX:KOSDAQ`, `BINANCE:BTCUSDT`로 구현되어 있습니다. |
| T005 | 🔴 | TradingView/Investing 전환 UI는 존재하지만 data-model의 `mode: tradingview | investing` 대신 구현에서는 `mode: main | sub`를 사용하고, 추가로 AlphaSquare 모드까지 존재합니다. |
| T006 | 🟢 | [이동]은 `loadChartFromInput()`을 호출하며 TradingView URL 갱신 경로가 존재합니다. |
| T007 | 🟢 | 새 탭 생성 직후 `createTabButtonElement` → `createTabContentElement` → `activateTab` 순으로 활성화하고 `saveAppData()`를 호출합니다. |
| T008 | 🔴 | T002/T005의 명세-구현 불일치가 확인되어 수정 대상입니다. |
| T009 | ⏳ | quickstart 시나리오 1~3 및 1초 이내(SC-001)는 브라우저 실행 검증이 필요합니다. |
| T010 | 🟢 | `parseCustomCharts()`가 구획(`<...>`), 쌍/삼중항, 레거시 형식을 휴리스틱으로 분기합니다. 문서화된 휴리스틱 한계와도 일치합니다. |
| T011 | 🔴 | `/api/finviz-image`, `/api/trading-economics`, `/api/fred`, `/api/ecos` 라우트는 존재합니다. 다만 계약 문서의 FRED/ECOS 응답 `{series:[...]}`와 현재 프론트/서버 흐름의 `success/data` 형태가 일치하지 않아 계약 기준으로는 불일치가 있습니다. 실제 외부 API 정상 응답 여부도 별도 실행 검증이 필요합니다. |
| T012 | 🟢 | 이미지와 다중 시리즈 데이터 모두 개별 항목의 실패를 전체 탭 실패로 전파하지 않도록 처리하는 코드가 있습니다. |
| T013 | 🟢 | 빈 설정/해석 결과가 없을 때 `등록된 차트가 없습니다` 안내를 렌더링합니다. |
| T014 | 🔴 | T010~T013 중 T011의 계약 불일치가 확인되어 수정 대상입니다. |
| T015 | ⏳ | quickstart 시나리오 4~5와 SC-002/SC-003은 실제 브라우저 및 외부 데이터 소스 검증이 필요합니다. |
| T016 | 🟢 | 드래그 종료 시 `saveAppData()`를 호출하고, 드래그 대상에서 `data-perm` 탭을 제외합니다. |
| T017 | 🟢 | 더블클릭 이름 변경 및 `saveAppData()`가 구현되어 있으며 `data-perm`은 대상에서 제외됩니다. |
| T018 | 🟢 | 우클릭 메뉴에서 확인 후 DOM 제거 + `delete tabData[tabId]` + `saveAppData()`가 수행됩니다. 고정 탭은 삭제 대상에서 제외됩니다. |
| T019 | 🔴 | T016~T018 자체는 정적 코드상 충족하지만, T001/T002/T005의 구조 불일치와 함께 수정 범위를 결정해야 합니다. |
| T020 | ⏳ | quickstart 시나리오 6의 실제 드래그/이름변경/삭제 동작은 브라우저 검증이 필요합니다. |
| T021 | 🟢 | `isCapturing` 검사로 `refreshOverseasCustomCharts()` 및 `refreshExchangeRateCharts()` 등 동적 데이터 로드를 캡처 중 건너뛰도록 되어 있습니다. |
| T022 | 🟢 | 커서/줌 동기화 대상은 `canvas[data-chart-type="multi-series"]`, `canvas[data-chart-type="te-single"]`로 한정되어 외부 iframe은 동기화 대상에 포함되지 않습니다. |
| T023 | ⏳ | 전체 quickstart 최종 실행은 브라우저 검증이 필요합니다. |

### Modification Pending

1. **T001/T002/T005** — 동적 탭 타입/데이터 모델과 실제 구현 구조의 정합성 검토 필요
2. **T011** — FRED/ECOS API contract와 실제 응답 구조 정합성 검토 필요
3. **T008/T014/T019** — 위 불일치 수정 후 처리

### Runtime / External Verification Pending

- T003a: `fred_api.py`, `requirements.txt` 루트 존재 및 Python 의존성 설치
- T009: Dynamic 차트 생성 및 TradingView/Investing 전환
- T015: Static/커스텀 차트 실제 데이터 및 실패 격리
- T020: 탭 관리 UI 실제 동작
- T023: 전체 quickstart

### 참고

- `spec.md`는 동적 탭을 `chart_grid`, `overseas_custom`, `exchange_rate` 3종으로 정의합니다.
- `data-model.md`는 DynamicTab의 `id/name/type/config`와 GridCell의 `mode=tradingview|investing`를 정의합니다.
- 현재 구현에는 `tab_grid_*`의 `tabData[id]` 배열 구조와 `mode=main|sub`가 존재하므로, 이는 단순 브라우저 실행 여부가 아니라 명세 정합성 관점에서 확인된 차이입니다.
