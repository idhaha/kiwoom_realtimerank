# Tasks: ADR 탭 — 등락비율 듀얼 차트

**Input**: Design documents from `/specs/002-adr-tab/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: 브라운필드 검증 작업. 자동화 테스트 대신 quickstart.md로 검증.

## Phase 1: Setup

- [ ] T001 서버가 정상 기동되고 `/api/adr` 라우트가 등록되어 있는지 확인 — `server.js`

## Phase 2: Foundational

**⚠️ CRITICAL**: 이 단계 완료 전 User Story 작업 시작 불가

- [ ] T002 `extractArrayFromHtml`의 괄호 균형 스택 파싱 로직이 research.md의 "정규식 폴백 포함" 결정대로 구현되어 있는지 확인 — `public/app.js`
- [ ] T003 [P] `getCombinedRange`(Y축 공유 스케일 계산)가 두 시장 데이터를 올바르게 합산하는지 확인 — `public/app.js`

**Checkpoint**: 파싱/스케일 공통 로직 검증 완료

---

## Phase 3: User Story 1 - KOSPI/KOSDAQ ADR 듀얼 차트 비교 (Priority: P1) 🎯 MVP

**Goal**: 두 차트가 8초 이내 렌더링되고 기준선(80/100/120)이 정확히 표시됨

**Independent Test**: ADR 탭 진입 시 두 차트가 정상 렌더링되고 원천 실패 시에도 화면이 비지 않는지 확인

### Implementation for User Story 1

- [ ] T004 [US1] `GET /api/adr` 응답이 contracts/api.md의 원본 HTML 패스스루 계약과 일치하는지 확인 (타임아웃 8000ms) — `server.js`
- [ ] T005 [P] [US1] 80(주황 점선)/100(빨강 점선)/120(초록 점선) 기준선과 80~120 음영(FR-003)이 정확히 그려지는지 확인 — `public/app.js`
- [ ] T006 [US1] 원천 응답이 비정상(100자 미만/빈 배열)일 때 기존 렌더링 유지 + "업데이트 실패" 표시(FR-006)를 확인 — `public/app.js`
- [ ] T007 [US1] KOSPI/KOSDAQ 데이터 길이 불일치 시 안전한 클램핑(FR-007)이 동작하는지 확인 — `public/app.js`
- [ ] T008 [US1] T004~T007에서 발견된 불일치 수정 — `server.js`, `public/app.js`
- [ ] T009 [US1] quickstart.md 시나리오 1~3 실행 후 SC-001, SC-003 확인

**Checkpoint**: User Story 1 독립적으로 동작

---

## Phase 4: User Story 2 - 조회 기간 전환 (Priority: P2)

**Goal**: 6m/1y/2y/5y/10y 기간 전환이 1초 이내 반영됨

### Implementation for User Story 2

- [ ] T010 [US2] 기간 선택기 5개 옵션(기본값 2년/480일)이 FR-004대로 구현되어 있는지 확인 — `public/app.js`
- [ ] T011 [US2] 기간 전환 시 최신 데이터가 항상 우측 끝에 오도록 스크롤 오프셋이 재정렬되는지 확인 — `public/app.js`
- [ ] T012 [US2] T010~T011 불일치 수정 — `public/app.js`
- [ ] T013 [US2] quickstart.md 시나리오 3(기간 버튼) 실행 후 SC-002 확인

**Checkpoint**: User Story 1, 2 모두 독립적으로 동작

---

## Phase 5: User Story 3 - 두 차트 커서·줌 동기화 (Priority: P3)

**Goal**: 한쪽 차트의 호버/패닝/줌이 반대편 차트에 실시간 동기화됨

### Implementation for User Story 3

- [ ] T014 [US3] `syncToKosdaq`/`syncToKospi` 커서 동기화(FR-005)가 `requestAnimationFrame` 기반으로 지연 없이 동작하는지 확인 — `public/app.js`
- [ ] T015 [US3] 패닝/스크롤바/휠 줌 동기화가 1:1로 일치하는지 확인 — `public/app.js`
- [ ] T016 [US3] T014~T015 불일치 수정 — `public/app.js`
- [ ] T017 [US3] quickstart.md 시나리오 4 실행 후 동기화 확인

**Checkpoint**: 3개 User Story 모두 독립적으로 동작

---

## Phase 6: Polish & Cross-Cutting Concerns

- [ ] T018 시세 지표 갱신 시 `saveAppData()`가 호출되지 않는지 확인(FR-008, 006-settings-sync와의 경계 확인) — `public/app.js`
- [ ] T019 [P] 비활성 탭 상태에서 캔버스 재렌더링 지연(FR-009)이 실제로 동작하는지 확인 — `public/app.js`
- [ ] T020 quickstart.md 전체 시나리오 최종 실행

## Dependencies & Execution Order

- Setup → Foundational → US1/US2/US3(병렬 가능, 서로 다른 UI 영역) → Polish

## Notes

- 기존 코드의 spec 준수 여부 검증 및 수정이 목적(Constitution 원칙 I).

---

## Verification Log

> 2026-09-30 기준 정적 코드 검증 기록. 현재는 코드 수정 없이 불일치만 기록한다.

### Completed / Confirmed

- **T001 🟢** — `server.js`에 `GET /api/adr` 라우트가 등록되어 있고 `axios.get(http://adrinfo.kr/chart...)` 프록시 구조가 확인된다. 요청 timeout은 8000ms로 설정되어 있다.
- **T002 🟢** — `extractArrayFromHtml()`에서 `[`/`]` 균형을 스택 카운터 방식으로 추적한 뒤 `JSON.parse()`를 시도하고, 실패 시 정규식 폴백을 수행한다.
- **T003 🟢** — `getCombinedRange()`가 KOSPI/KOSDAQ 각각에 대해 offset을 데이터 길이에 맞게 clamp한 뒤 두 배열의 값을 합산하여 공통 min/max를 계산한다.
- **T004 🟢** — `/api/adr`는 원본 응답을 `res.send(response.data)`로 그대로 전달하고 timeout은 8000ms이다.
- **T005 🟢** — `drawLineChart()`에 80/100/120 기준선과 80~120 구간 음영이 구현되어 있다. 기준선은 각각 주황/빨강/초록 점선으로 그린다.
- **T011 🟢** — 기간 버튼 클릭 시 각 차트의 `scrollOffset`을 `데이터 길이 - 기간 거래일 수`로 재설정하여 최신 데이터가 우측 끝에 오도록 처리한다.
- **T018 🟢** — `updateAdrFromSource()` 자체에서는 `saveAppData()`를 호출하지 않는다. ADR 시세 갱신 자체가 설정 저장을 직접 트리거하는 경로는 확인되지 않았다.

### Mismatches Found

- **T006 🔴** — 원천 응답이 100자 미만이면 실패 처리하지만, HTML은 정상 길이여도 `parseAdrHtml()` 결과가 KOSPI/KOSDAQ 모두 빈 배열인 경우에는 예외가 발생하지 않는다. 이후 `tabData[ADR_TAB_ID].adr`를 빈 데이터로 덮어쓰고 `renderAdr()`를 호출하므로 기존 차트가 사라질 수 있다. `FR-006`의 "기존 렌더링 유지 + 업데이트 실패"와 불일치한다.
- **T007 🟠** — 길이 불일치 시 경고 로그는 남기고 `getCombinedRange()` 및 `drawLineChart()` 내부에서 offset을 clamp하여 범위를 벗어난 접근은 방지한다. 다만 spec의 "짧은 쪽 길이에 맞춰 안전하게 자른다"는 의미와 정확히 같은 방식으로 양쪽 시계열을 정렬/절단하는지는 실제 데이터로 확인이 필요하다.
- **T010 🔴** — ADR 기간 버튼의 HTML 기본 active 값은 `1y`인데, spec은 기본값을 `2년`으로 요구한다. 또한 `renderAdr()`의 초기 기본 표시 거래일 수도 480이 아니라 500으로 설정되어 있다.
- **T014 🟠** — `syncToKosdaq()`/`syncToKospi()`와 `requestAnimationFrame()` 기반 hover/pan 동기화는 구현되어 있다. 다만 현재 동기화 값이 `hoveredIndex` 중심이라 KOSPI/KOSDAQ 데이터 길이 또는 휴장일 차이가 있을 때 "동일 일자"가 정확히 맞는지는 실제 데이터로 검증해야 한다.
- **T015 🔴** — 마우스 패닝 및 스크롤바 드래그에서는 `syncCallback()`이 호출되지만, wheel 이벤트에서는 `scrollOffset`만 변경하고 반대편 차트의 `syncCallback()`을 호출하지 않는다. 또한 ADR 차트 자체에는 다른 차트로 줌 상태를 전파하는 별도 zoom 동기화 로직이 확인되지 않는다. 따라서 FR-005의 패닝/줌 1:1 동기화 전체를 현재 코드만으로 충족한다고 볼 수 없다.
- **T019 🔴** — `startAdrAutoRefresh()`는 ADR 탭의 활성 여부와 관계없이 `updateAdrFromSource()`를 실행한다. `updateAdrFromSource()` 역시 `isAdrActive`를 확인하지만 이는 실패 시 alert 여부에만 사용되고, 성공 시에는 비활성 탭이어도 `renderAdr()`를 호출한다. FR-009의 "비활성 탭에서 캔버스 재렌더링 지연"과 불일치한다.

### Pending Runtime Verification

- **T001** — 실제 서버 기동 성공 여부는 실행 환경에서 확인 필요.
- **T007** — KOSPI/KOSDAQ 실제 길이 불일치 데이터를 넣어 안전한 클램핑을 확인해야 한다.
- **T009** — quickstart 시나리오 1~3에서 초기 렌더링/실패 상태/8초 이내 표시를 실제 확인해야 한다.
- **T013** — 기간 버튼 5개를 실제 브라우저에서 각각 클릭하여 1초 이내 전환 여부를 확인해야 한다.
- **T014** — 두 차트의 실제 hover/pan 동기화와 휴장일 데이터 차이 상황을 브라우저에서 확인해야 한다.
- **T017** — quickstart 시나리오 4의 실제 커서/패닝 동기화를 실행해야 한다.
- **T020** — 네트워크 차단 후 기존 차트 유지 여부를 실제 브라우저에서 확인해야 한다.

### Current Next Step

- **코드 수정 보류.**
- 우선 T006/T010/T015/T019를 주요 수정 후보로 기록한다.
- 실제 브라우저 quickstart 검증을 수행한 뒤 수정 범위를 확정한다.
- 이후 T008/T012/T016에서 코드 수정 여부를 일괄 결정하고, 마지막으로 T009/T013/T017/T020 회귀 검증을 진행한다.
