# Tasks: 설정 저장 및 동기화

**Input**: Design documents from `/specs/006-settings-sync/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: 브라운필드 검증 작업. quickstart.md로 검증.

## Phase 1: Setup

- [ ] T001 `user_settings.json`이 `.gitignore`에 포함되어 있는지 확인(Constitution 원칙 III) — `.gitignore`

## Phase 2: Foundational

**⚠️ CRITICAL**

- [ ] T002 `getSerializedState()`가 data-model.md의 AppSettingsSnapshot 필드를 모두 포함하는지 확인 — `public/app.js`
- [ ] T003 [P] `GET/POST /api/settings`가 contracts/api.md와 일치하는지(캐시 방지 헤더, 50MB 한도) 확인 — `server.js`

**Checkpoint**: 저장 스냅샷 구조 검증 완료

---

## Phase 3: User Story 1 - 설정 자동 저장 (Priority: P1) 🎯 MVP

**Goal**: 구성 변경 시 로컬 즉시 기록 후 서버 저장이 자동 발생

**Independent Test**: 탭 이름 변경 후 새로고침해도 유지되는지 확인

### Implementation for User Story 1

- [ ] T004 [US1] `saveAppData()`가 탭 추가/삭제/이름변경/순서변경/차트입력/간격변경/관심종목변경/메모저장 시 호출되는지(FR-001) 확인 — `public/app.js`
- [ ] T005 [P] [US1] 로컬 저장 → 서버 전송 순서(FR-002)가 정확히 지켜지는지 확인 — `public/app.js`
- [ ] T006 [US1] 서버 저장 실패 시 로컬 유지 + 사용자 경고(FR-003)를 확인 — `public/app.js`
- [ ] T007 [US1] `isInitializing` 중 자동 저장 잠금(FR-007)이 동작하는지 확인 — `public/app.js`
- [ ] T008 [US1] T004~T007 불일치 수정 — `public/app.js`
- [ ] T009 [US1] quickstart.md 시나리오 1~2 실행 후 SC-001 확인

**Checkpoint**: User Story 1 독립적으로 동작

---

## Phase 4: User Story 2 - 여러 PC 간 설정 동기화 (Priority: P2)

**Goal**: 시작 시 서버 설정 우선 적용, 서버 접근 불가 시 로컬 폴백

### Implementation for User Story 2

- [ ] T010 [US2] 서버에 비어있지 않은 `tabs`가 있으면 무조건 서버 데이터를 우선 채택(FR-004)하는지 확인 — `public/app.js`
- [ ] T011 [US2] 서버 접근 실패 시 유효한 로컬 설정으로 대체(FR-005)되는지 확인 — `public/app.js`
- [ ] T012 [US2] 서버·로컬 모두 없을 때 고정 탭+기본 Rank로 시작(FR-006)하는지 확인 — `public/app.js`
- [ ] T013 [US2] T010~T012 불일치 수정 — `public/app.js`
- [ ] T014 [US2] quickstart.md 시나리오 2~3 실행 후 SC-002, SC-003 확인

**Checkpoint**: User Story 1, 2 모두 독립적으로 동작

---

## Phase 5: User Story 3 - 전체 설정 백업/복원 (Priority: P3)

**Goal**: TXT+JSON 내보내기, JSON 백업으로 전체 복원

### Implementation for User Story 3

- [ ] T015 [US3] 사용자 정의 탭이 하나 이상 있을 때만 내보내기 진행(없으면 안내 후 종료)이 FR-009대로 동작하는지 확인 — `public/app.js`
- [ ] T016 [P] [US3] TXT/JSON 파일이 순차(약 100ms 간격)로 다운로드되는지 확인 — `public/app.js`
- [ ] T017 [US3] 사용자 정의 탭 단일 TXT export/import(FR-008)가 다른 탭에 영향 주지 않는지 확인 — `public/app.js`
- [ ] T018 [US3] JSON 전체 백업 복원 시 확인 절차(FR-010)를 거치는지, `tabs`/`contents` 필드 존재 여부로 전체 백업을 판별하는지 확인 — `public/app.js`
- [ ] T019 [US3] T015~T018 불일치 수정 — `public/app.js`
- [ ] T020 [US3] quickstart.md 시나리오 4~6 실행 후 SC-004 확인

**Checkpoint**: 3개 User Story 모두 독립적으로 동작

---

## Phase 6: Polish & Cross-Cutting Concerns

- [ ] T021 서버가 API 키 등 민감정보를 `user_settings.json`에 저장하지 않는지 재확인(Constitution 원칙 III, FR-011) — `server.js`
- [x] T022 [P] 동시 저장 충돌 시 "마지막 저장 우선" 동작(FR-012)이 문서화된 한계로 명확히 기록되어 있는지 확인 — 마이그레이션 감사에서 확인한 기존 3.4절 충돌 정책과 대조 완료
- [ ] T023 quickstart.md 전체 시나리오 최종 실행

## Dependencies & Execution Order

- Setup → Foundational → US1 → US2(US1 전제) → US3(US1/US2와 독립적으로 병렬 가능) → Polish

## Notes

- FR-012(동시 저장 시 마지막 저장 우선, 병합 없음)는 현재 정책으로 "수정 대상 버그"가 아니라 "문서화된 한계"로 취급한다. 다중 사용자 확장이 실제 필요해지면 별도 spec으로 분리해 재설계할 것.

---

## Verification Log — 2026-09-30

> 원칙: 이번 단계에서는 코드 수정 없이 현재 구현을 검증했습니다. 브라우저에서만 확인 가능한 항목은 `⏳`로 남겼습니다.

### Phase 1 / Foundational

| Task | 결과 | 검증 내용 |
|---|---|---|
| T001 | ⏳ | 현재 제공된 소스 집합에는 `.gitignore` 파일이 없어 `user_settings.json`이 실제로 git ignore 되는지는 확인하지 못했습니다. |
| T002 | 🟢 | `getSerializedState()`가 `activeTabId`, `tabs`, `contents`, `rankInterval`, `adrInterval`, `watchlistGroupId`, `memoHtml`, `memoDelta`, `updatedAt`를 모두 반환합니다. `memoTabIconMigrationV1`은 추가 필드입니다. |
| T003 | 🟢 | `GET /api/settings`는 `Cache-Control: no-store...`, `Pragma: no-cache`, `Expires: 0`을 설정하고 계약 형태 `{success:true,data}` / `data:null`을 반환합니다. `POST /api/settings`도 `{success:true}`를 반환합니다. Express JSON body limit은 50MB입니다. |

### User Story 1

| Task | 결과 | 검증 내용 |
|---|---|---|
| T004 | 🔴 | 탭 추가/삭제/이름변경/순서변경/차트 입력/간격 변경/관심종목 변경에는 `saveAppData()` 호출이 확인됩니다. 그러나 메모 저장은 `saveMemoToServer()`를 별도 호출하며 `saveAppData()`를 호출하지 않습니다. FR-001의 “메모 저장 시 전체 설정 자동 저장”과 구현이 다릅니다. |
| T005 | 🟢 | `saveAppData()`에서 `localStorage.setItem(STORAGE_KEY, ...)`을 먼저 수행한 뒤 `syncSettingsToServer(storageData)`를 호출합니다. |
| T006 | 🟢 | 서버 저장 실패/응답 false 시 `alert()`로 사용자에게 실패를 알리고, 서버 전송 실패와 무관하게 이미 로컬 저장이 완료된 구조입니다. |
| T007 | 🟢 | `saveAppData()` 첫 줄에서 `isInitializing`이면 저장을 수행하지 않고 종료합니다. `applyData()`도 복원 중 `isInitializing = true`로 잠그며 완료 후 해제합니다. |
| T008 | 🔴 | T004 불일치가 있으므로 수정 대상입니다. |
| T009 | ⏳ | quickstart 시나리오 1~2와 SC-001은 실제 브라우저에서 확인해야 합니다. |

### User Story 2

| Task | 결과 | 검증 내용 |
|---|---|---|
| T010 | 🟢 | 초기화에서 서버 데이터를 먼저 가져오고, `serverData.tabs.length > 0`이면 항상 서버 데이터를 `finalData`로 선택합니다. |
| T011 | 🟢 | 서버 로드 실패 시 `loadAppDataFromServer()`가 `null`을 반환하고 이후 `localData`를 `finalData`로 사용합니다. |
| T012 | 🟢 | 서버/로컬 설정이 모두 없으면 `ensurePermanentTabs()` 후 `activateTab(PERM_TAB_ID)`를 실행합니다. |
| T013 | 🟢 | T010~T012의 정적 구현상 불일치는 발견되지 않았습니다. |
| T014 | ⏳ | 서버 재시작/다른 브라우저 및 서버 접근 불가 상황은 실제 환경에서 확인해야 합니다. |

### User Story 3

| Task | 결과 | 검증 내용 |
|---|---|---|
| T015 | 🟢 | `bulkExportSettings()`는 `overseas_custom` 또는 `exchange_rate` 탭이 하나도 없으면 안내 후 종료하고 다운로드를 실행하지 않습니다. |
| T016 | 🟢 | TXT를 즉시 다운로드하고 JSON은 `setTimeout(..., 100)` 후 다운로드하도록 구현되어 있습니다. |
| T017 | 🟢 | TXT import는 `[탭이름]` 단위로 커스텀 탭을 생성/갱신하며 기존 고정 탭이나 메모/갱신 간격을 직접 변경하는 로직은 없습니다. |
| T018 | 🟢 | JSON에서 `data.tabs && data.contents`를 확인한 뒤 전체 백업으로 판별하고, `confirm()` 후 `applyFullStateBackup(data)`를 호출합니다. |
| T019 | 🟢 | T015~T018에 대한 정적 코드 불일치는 확인되지 않았습니다. |
| T020 | ⏳ | 실제 TXT/JSON 다운로드 및 복원 결과는 브라우저에서 확인해야 합니다. |

### Polish

| Task | 결과 | 검증 내용 |
|---|---|---|
| T021 | 🟢 | 현재 `getSerializedState()`가 저장하는 스냅샷에는 API key/token 필드가 없고, 서버 `/api/settings`는 설정 스냅샷을 `user_settings.json`에 저장합니다. 앱 설정 저장 경로에서 API 키를 추가하는 코드는 확인되지 않았습니다. 단, `.gitignore`와 실제 파일 내용까지는 별도 확인이 필요합니다. |
| T022 | 🟢 | 마이그레이션 감사에서 확인한 기존 3.4절 정책을 대조한 결과, 공유 서버 파일에 전체 스냅샷을 저장하고 동시 저장 시 마지막 POST의 전체 상태가 남으며 필드 병합/충돌 알림이 없다는 한계가 006의 snapshot/last-write-wins 설명과 일치함을 확인했다. |
| T023 | ⏳ | quickstart 전체 시나리오 1~6은 실제 브라우저/서버 환경에서 실행해야 합니다. |

### Modification Pending

1. **T004 / T008** — 메모 저장 시 FR-001의 전체 설정 자동 저장 요구와 현재 `saveMemoToServer()` 별도 저장 경로의 정합성 검토가 필요합니다.
2. T001 — `.gitignore` 확인 필요.
3. T022 — 마이그레이션 감사에서 확인한 기존 3.4절 충돌 정책과 대조 완료. 이후에는 006 Spec Kit 문서를 기준으로 유지한다.

### Runtime Verification Pending

- T009: 탭 이름 변경 후 새로고침 / 서버 중지 상태 저장
- T014: 다른 브라우저 서버 설정 우선 / 서버 장애 로컬 폴백
- T020: TXT/JSON 다운로드 및 복원
- T023: 전체 quickstart 1~6

### 현재 결론

정적 코드 기준으로 **핵심적인 수정 후보는 T004 하나**입니다.  
특히 이번 검증에서 `saveAppData()`가 대부분의 설정 변경을 자동 저장하지만 **메모 저장만 별도의 `/api/settings/memo` 경로를 사용**한다는 점이 확인되었습니다. Spec의 FR-001은 메모 저장도 전체 설정 자동 저장 대상이라고 명시하므로, 코드 수정 전에 이 경계를 결정해야 합니다.
