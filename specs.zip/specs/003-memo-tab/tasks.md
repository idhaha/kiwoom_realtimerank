# Tasks: 메모 탭 — 캘린더 및 리치 텍스트 메모

**Input**: Design documents from `/specs/003-memo-tab/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: 브라운필드 검증 작업. quickstart.md로 검증.

## Phase 1: Setup

- [ ] T001 Quill v1.3.6, FullCalendar v6.1.10 CDN 스크립트가 `public/index.html`에 정상 로드되는지 확인

## Phase 2: Foundational

**⚠️ CRITICAL**

- [ ] T002 Quill/FullCalendar가 탭이 처음 활성화(`activateTab('tab_memo')`)되는 시점에만 초기화되는지 확인(숨김 탭 높이 0 에러 방지, research.md 결정) — `public/app.js`
- [ ] T003 [P] `POST /api/settings`, `GET /api/settings`가 정상 동작하는지 확인(006-settings-sync와 공유 엔드포인트) — `server.js`

**Checkpoint**: 초기화/저장 공통 인프라 검증 완료

---

## Phase 3: User Story 1 - 리치 텍스트 메모 작성 및 저장 (Priority: P1) 🎯 MVP

**Goal**: 메모를 작성하고 명시적 저장으로 HTML+Delta가 로컬·서버에 저장됨

**Independent Test**: 메모 작성 → 저장 → 새로고침 후 유지 확인

### Implementation for User Story 1

- [ ] T004 [US1] 메모 저장이 타이핑 중 자동 발생하지 않고 [저장] 버튼 클릭 시에만 발생하는지 확인(FR-004) — `public/app.js`
- [ ] T005 [P] [US1] `memoHtml`, `memoDelta` 이중 저장(FR-003)이 data-model.md 필드와 일치하는지 확인 — `public/app.js`
- [ ] T006 [US1] [Today] 버튼이 현재 일시를 굵게 삽입하는지 확인(FR-002) — `public/app.js`
- [ ] T007 [US1] 서버 통신 실패 시 로컬 저장소(`memoContent_html`, `memoContent_delta`) 보존(FR-006)을 확인 — `public/app.js`
- [ ] T008 [US1] [새로고침] 버튼이 전체 페이지 리로드 없이 서버 최신값으로 에디터만 갱신하는지 확인(FR-005) — `public/app.js`
- [ ] T009 [US1] T004~T008 불일치 수정 — `public/app.js`
- [ ] T010 [US1] quickstart.md 시나리오 1~3 실행 후 SC-001, SC-002 확인

**Checkpoint**: User Story 1 독립적으로 동작

---

## Phase 4: User Story 2 - Google 캘린더 일정 관리 (Priority: P2)

**Goal**: Google 인증 후 일정 CRUD 및 공휴일 조회가 정상 동작

### Implementation for User Story 2

- [ ] T011 [US2] GIS OAuth2 Implicit Flow가 앱 구동 시 자동 실행되지 않고 사용자 동작 시에만 트리거되는지 확인(FR-010) — `public/app.js`
- [ ] T012 [US2] 사용자 캘린더 + 대한민국 공휴일 캘린더 병렬 조회(FR-007)가 contracts/api.md와 일치하는지 확인 — `public/app.js`
- [ ] T013 [P] [US2] 공휴일 이벤트가 읽기 전용으로 표시되는지(FR-008) 확인 — `public/app.js`
- [ ] T014 [US2] 일정 등록/수정/삭제(FR-009)가 각각 POST/PUT/DELETE로 정상 반영되는지 확인 — `public/app.js`
- [ ] T015 [US2] 401 토큰 만료 시 자동 재인증(FR-011)이 동작하는지 확인 — `public/app.js`
- [ ] T016 [US2] T011~T015 불일치 수정 — `public/app.js`
- [ ] T017 [US2] quickstart.md 시나리오 4~6 실행

**Checkpoint**: User Story 1, 2 모두 독립적으로 동작

---

## Phase 5: Polish & Cross-Cutting Concerns

- [ ] T018 숨김 탭 초기화 예외 케이스(Edge Case) 재확인 — `public/app.js`
- [ ] T019 quickstart.md 전체 시나리오(1~7) 최종 실행

## Dependencies & Execution Order

- Setup → Foundational → US1 → US2(US1과 독립적으로 병렬 가능) → Polish

## Notes

- Google Calendar 관련 작업(US2)은 실제 Google 계정 인증이 필요하므로 검증 시 테스트 계정을 사용할 것을 권장.

---

## Verification Log — 2026-09-30

> 원칙: 현재 `br_oracle` 구현을 기준으로 정적 검증했습니다. 코드 수정은 하지 않았으며, 실제 브라우저/Google 계정이 필요한 quickstart 항목은 별도 보류했습니다.

### Phase 1 / Foundational

- [x] **T001 🟢** `public/index.html`에 Quill **1.3.6**, FullCalendar **6.1.10**, Google Identity Services CDN 스크립트가 존재함.
- [x] **T002 🟢** `activateTab('tab_memo')` → `initializeTab()` 경로에서만 `initMemoEditor()` / `initCalendar()`가 호출되도록 구현되어 있음. 숨김 상태에서 즉시 초기화하는 코드는 확인되지 않음.
- [x] **T003 🟢** `GET /api/settings`, `POST /api/settings`가 존재하고 200 응답 `{ success: true, ... }` 계약에 맞는 구현이 확인됨.

### User Story 1

- [ ] **T004 🔴** 저장 버튼 클릭 시에만 서버 저장되는 구조는 맞지만, `[Today]` 버튼 등 사용자 입력에 대한 자동 저장 여부와 실제 브라우저 동작은 quickstart에서 추가 확인 필요.
  - 코드상 `text-change` 자동 저장 블록은 주석 처리되어 있음.
  - 수동 저장 버튼은 `saveMemo()`를 호출함.
- [x] **T005 🟢** `memoHtml` + `memoDelta`를 함께 `localStorage` 및 서버 저장 경로로 전달함. Delta는 Quill Delta 객체로 저장됨.
- [ ] **T006 🔴** `[Today]` 구현이 현재 **날짜만** 삽입함: `[YYYY-MM-DD]`.
  - spec/FR-002는 **현재 일시 문자열**을 요구하므로 현재 구현은 시간까지 포함하지 않음.
- [x] **T007 🟢** `saveMemo()`가 서버 저장 전에 `memoContent_html`, `memoContent_delta`를 `localStorage`에 먼저 기록하므로 서버 통신 실패 시 로컬 내용이 보존됨.
- [x] **T008 🟢** `[서버에서 불러오기]` 버튼은 `loadAppDataFromServer()` → `applyMemoState()`로 에디터 상태만 갱신하며 페이지 전체 reload를 호출하지 않음.
- [ ] **T009 ⏳** T004~T008에서 발견된 불일치 수정은 아직 수행하지 않음. 현재 전략대로 코드 수정은 보류.
- [ ] **T010 ⏳** quickstart 시나리오 1~3은 실제 브라우저 실행 검증 필요.

### User Story 2

- [x] **T011 🟢** GIS `initTokenClient()`는 토큰 클라이언트를 준비할 뿐 자동 인증 요청을 보내지 않음. 실제 `requestAccessToken()` 호출은 `동기화`/캘린더 조작 시점에 발생함.
- [x] **T012 🟢** `fetchCalendarEvents()`에서 기본 캘린더와 대한민국 공휴일 캘린더를 `Promise.all()`로 병렬 조회함.
- [x] **T013 🟢** 공휴일 이벤트에 `extendedProps.isHoliday=true`, `editable:false`가 설정되고 모달에서 저장/삭제 버튼이 숨겨짐.
- [x] **T014 🟢** 일정 생성은 POST, 수정은 PUT, 삭제는 DELETE로 Google Calendar API를 호출함.
- [ ] **T015 🔴** 401 자동 재인증 처리가 불완전함.
  - 조회(`fetchCalendarEvents`)의 기본 캘린더 응답에서 401을 감지해 `requestCalendarAccess()`를 호출함.
  - 하지만 일정 생성/수정/삭제의 POST/PUT/DELETE 응답에서는 401 발생 시 자동 재인증 로직이 없음.
- [ ] **T016 ⏳** T011~T015 불일치 수정은 아직 수행하지 않음.
- [ ] **T017 ⏳** quickstart 시나리오 4~6은 실제 Google 계정/브라우저 인증이 필요.

### Polish

- [x] **T018 🟢** 현재 구현은 메모 탭이 실제 활성화된 뒤 Quill/FullCalendar를 초기화하는 구조임. 숨김 탭에서의 최초 초기화는 피하도록 되어 있음.
- [ ] **T019 ⏳** quickstart 전체 1~7 최종 실행은 브라우저/Google 인증 환경에서 수행 필요.

### 현재 결론

**코드 수정 없이 검증만 진행한 결과, 003-memo-tab에서 명확히 수정 대기 항목은 다음 2개입니다.**

1. **T006 / FR-002:** `[Today]`가 날짜만 삽입하고 시간이 없음.
2. **T015 / FR-011:** 일정 CRUD 요청의 401 토큰 만료 시 자동 재인증이 빠져 있음.

추가로 **T004/T010**은 브라우저 실행 검증이 남아 있으며, 정적 코드상 자동 저장은 주석 처리되어 있습니다.
