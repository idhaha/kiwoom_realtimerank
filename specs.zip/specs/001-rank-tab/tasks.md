# Tasks: Rank 탭 — 실시간 종목 순위 모니터링

**Input**: Design documents from `/specs/001-rank-tab/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: 이 기능은 브라운필드(기존 구현) 검증 작업이므로 별도 자동화 테스트는 요청되지 않았다(Constitution 원칙 IV). 대신 quickstart.md 시나리오로 검증한다.

**Organization**: 사용자 스토리별로 그룹화. 각 스토리는 "코드가 spec/contracts와 일치하는지 검증 → 불일치 수정 → quickstart 확인" 순서를 따른다.

## Phase 1: Setup

- [x] T001 `.env`에 `KIWOOM_APPKEY`, `KIWOOM_SECRETKEY`가 설정되어 있는지 확인 (루트 `.env`)
- [x] T002 [P] `npm ci`로 `package.json` 의존성이 정상 설치되는지 확인

**Checkpoint**: 서버 실행 가능 상태 확보

---

## Phase 2: Foundational (Blocking Prerequisites)

**⚠️ CRITICAL**: 이 단계 완료 전에는 User Story 작업을 시작할 수 없음

- [x] T003 Kiwoom OAuth 토큰 캐싱 로직(`cachedToken`, `tokenExpiryTime`)이 research.md의 "토큰 재사용, 무효화 시 즉시 폐기" 결정과 일치하는지 `server.js`에서 확인
- [x] T004 [P] 시장 구분(KOSPI/KOSDAQ) 캐시가 4개 패널(거래대금/실시간순위/대주가능/관심종목)에서 공유되는지 `server.js`에서 확인 (data-model.md "관계 및 상태" 참고)
- [x] T005 [P] 종목별 상세 조회 순차 처리 + 100ms 지연 로직이 `server.js`에 구현되어 있는지 확인 (FR-015)

**Checkpoint**: 공통 인프라 검증 완료 — User Story별 작업 시작 가능

---

## Phase 3: User Story 1 - 거래대금·실시간 조회 순위 확인 (Priority: P1) 🎯 MVP

**Goal**: 거래대금 상위·실시간 조회 순위 패널이 자동/수동 갱신되며 5초 이내 초기 표시

**Independent Test**: Rank 탭 진입 시 두 패널에 각 20개 항목이 표시되고, 새로고침 주기 변경/수동 조회가 동작하는지 확인

### Implementation for User Story 1

- [ ] T006 [US1] `GET /api/transaction_rank` 응답 필드가 contracts/api.md와 일치하는지 확인 (`rank`, `stk_cd`, `stk_nm`, `mkt_type`, `fluc_rt`, `trde_amt`, `concentration_rate`) — `server.js`
- [ ] T007 [US1] `GET /api/stock`의 rank 응답이 data-model.md의 WatchRankEntry 필드와 일치하는지 확인 — `server.js`
- [ ] T008 [P] [US1] 상위 20개 제한 및 시장 구분 색상 표시(FR-007, FR-009)가 렌더링되는지 확인 — `public/app.js`
- [x] T009 [US1] 새로고침 주기 선택(`#refreshInterval`: 30초/1분/10분/1시간/당일누적)이 FR-002대로 동작하는지 확인 — `public/app.js`
- [ ] T010 [US1] 수동 조회 버튼(`#manualRefresh`)이 4개 패널을 동시에 갱신 시도하는지 확인 (FR-003) — `public/app.js`
- [x] T011 [US1] 통신 실패 시 에러 상태 표시(FR-006)가 구현되어 있는지 확인 — `public/app.js`
- [ ] T011a [US1] `#lastUpdate`가 마지막 성공 데이터 수신 시각으로 정확히 갱신되는지 확인 (FR-004) — `public/app.js`
- [ ] T011b [US1] `#statusText`가 대기/로딩 중/완료/실패 4개 상태를 정확히 전환하는지 확인 (FR-005) — `public/app.js`
- [ ] T012 [US1] T006~T011에서 발견된 spec 대비 불일치를 수정 — `server.js`, `public/app.js`
- [ ] T013 [US1] quickstart.md 시나리오 1~3 실행 후 SC-001, SC-002 충족 확인

**Checkpoint**: User Story 1 독립적으로 완전히 동작

---

## Phase 4: User Story 2 - 대주가능 종목 확인 (Priority: P2)

**Goal**: 한투 eFriend 연동으로 대주가능 종목을 등락률 순으로 표시하며, 키 미설정 시에도 서버가 정상 동작

**Independent Test**: `.env`에서 `EFRIEND_*`를 제거한 뒤에도 서버가 크래시 없이 빈 목록을 반환하는지 확인

### Implementation for User Story 2

- [ ] T014 [US2] `EFRIEND_*` 환경변수가 없을 때 `GET /api/stock`의 efriend 응답이 빈 배열을 반환하는지 확인 (FR-012) — `server.js`
- [ ] T015 [US2] 매매가능수량 강조 표시 및 매매가능금액(현재가×수량) 계산·표시(FR-011)를 확인 — `public/app.js`
- [ ] T016 [US2] T014~T015에서 발견된 불일치를 수정 — `server.js`, `public/app.js`
- [ ] T017 [US2] quickstart.md 시나리오 4 실행 후 FR-012 및 SC-003(eFriend 장애 시 나머지 3개 패널 정상 동작) 확인

**Checkpoint**: User Story 1과 2가 모두 독립적으로 동작

---

## Phase 5: User Story 3 - 관심종목 하락률 순위 확인 (Priority: P3)

**Goal**: 사용자가 선택/입력한 관심종목 그룹의 하락률 상위 종목을 확인하고, 선택값이 유지됨

**Independent Test**: 관심종목 그룹을 변경한 뒤 새로고침해도 선택값이 유지되는지 확인

### Implementation for User Story 3

- [ ] T018 [US3] `GET /api/watchlist_groups`, `GET /api/watchlist_rank`가 contracts/api.md와 일치하는지 확인 — `server.js`
- [ ] T019 [US3] 관심종목 그룹 선택이 `localStorage`(`watchlist_selected_group`)에 저장·복원되는지 확인 (FR-014) — `public/app.js`
- [ ] T020 [US3] 그룹 ID 직접 입력이 드롭다운 선택보다 우선 적용되는지 확인 — `public/app.js`
- [ ] T021 [US3] T018~T020에서 발견된 불일치를 수정 — `server.js`, `public/app.js`
- [ ] T022 [US3] quickstart.md 시나리오 5 실행 후 SC-004 충족 확인

**Checkpoint**: 3개 User Story 모두 독립적으로 동작

---

## Phase 6: Polish & Cross-Cutting Concerns

- [ ] T023 [P] 발견된 수정 사항 중 현재 Feature Spec Kit 문서와 다른 부분이 있으면 문서 갱신
- [ ] T024 장 운영 시간 외 전일 마감 데이터 정상 표시(FR-017)를 4개 패널 모두에서 확인
- [ ] T025 캡처 모드 중 자동 갱신 중단(FR-018), 비활성 탭에서의 조용한 실패 처리(FR-019)를 `public/app.js`에서 확인
- [ ] T026 quickstart.md 전체 시나리오(1~6)를 순서대로 실행하여 SC-001~004 최종 확인

---

- [ ] T027 [P] 전역 `전체조회`가 Rank/ADR/동적 탭 갱신 명령을 호출하고 버튼 상태/완료 문구가 FR-020대로 동작하는지 브라우저에서 확인 — `public/app.js`
- [ ] T028 [P] 작은 화면 `더 보기` 메뉴의 열기/닫기 및 바깥 클릭 종료가 FR-021대로 동작하는지 브라우저에서 확인 — `public/app.js`, `public/index.html`

## Verification Log

> 2026-09-30 기준 검증 진행 기록. 체크박스는 **검증 완료**를 의미하며, 발견된 불일치가 있는 태스크는 수정 전까지 체크하지 않는다. 실제 코드 수정은 T012에서 일괄 결정/반영한다.

### Completed

- **T001 🟢** — 루트 `.env`에 `KIWOOM_APPKEY`, `KIWOOM_SECRETKEY`가 존재함을 확인. 실제 비밀값은 기록하지 않는다.
- **T002 🟢** — `npm ci` 성공 확인 (`193 packages added`, `194 packages audited`). 설치 자체는 정상이며, 보고된 npm 취약점은 별도 후속 검토 사항이다.
- **T003 🟢** — `server.js`에서 `cachedToken`/`tokenExpiryTime`을 이용한 OAuth 토큰 재사용 및 만료 시 재발급을 확인. 무효 토큰 조건에서 두 값을 초기화하는 로직도 확인.
- **T004 🟢** — `server.js`의 전역 `marketCache`가 거래대금/실시간순위/대주가능/관심종목 처리에서 공통 사용됨을 확인.
- **T005 🟢** — `/api/transaction_rank`의 종목 상세 조회가 `chunkSize = 1`로 순차 처리되고 각 처리 후 100ms 지연됨을 확인.

### Mismatches Found

- **T006 🔴** — `contracts/api.md`는 `GET /api/transaction_rank` 성공 응답을 최상위 `items` 배열로 정의하지만, 현재 `server.js`는 최상위 `data` 배열을 반환한다. 현재 `public/app.js`도 `result.data`를 사용하므로, 서버만 변경하면 프론트엔드가 깨질 수 있다. T012에서 계약/구현 중 기준을 결정한 후 수정한다.
- **T007 🔴** — `data-model.md`의 `WatchRankEntry`는 `bigd_rank`, `stk_cd`, `stk_nm`, `mkt_type`, `base_comp_chgr`, `trde_amt`를 요구한다. 현재 `/api/stock`은 원본 `stock`을 spread하고 `mkt_type`, `trde_amt`를 보강하지만 `bigd_rank`/`base_comp_chgr`를 명시적으로 매핑하거나 보장하지 않는다. 실제 Kiwoom 원본 응답에 해당 필드가 있을 가능성은 있으나, 현재 코드만으로 계약 필드 보장을 확인할 수 없어 불일치로 기록한다. T012에서 수정 여부를 결정한다.
- **T008 🔴** — `public/app.js`에서 실시간 조회 순위(`renderTable`)와 거래대금 순위(`loadTransactionRank`) 모두 `slice(0, 20)`으로 상위 20개 제한은 구현되어 있다. 그러나 시장 구분은 단순히 `<td class="market-type">${marketLabel}</td>`로 출력할 뿐, K/Q에 따라 별도 색상 클래스나 스타일을 적용하지 않는다. `price-up`/`price-down`은 등락률 색상용이지 시장 구분 색상이 아니다. 따라서 FR-007의 20개 제한은 충족하지만 FR-009의 시장 구분 색상 표시는 현재 코드에서 확인되지 않아 T008은 미완료로 기록한다. T012에서 수정 여부를 결정한다.
- **T009 🟢** — `#refreshInterval`의 30초/1분/10분/1시간/당일누적 옵션과 선택값에 따른 자동 갱신 로직을 확인했다.
- **T010 🔴** — `#manualRefresh`가 `loadData()`, `loadTransactionRank()`, `loadWatchlistRank()`만 호출하고 ADR 갱신(`updateAdrFromSource()`)은 호출하지 않아 4개 패널 동시 갱신 요구와 불일치한다. T012에서 수정한다.
- **T011 🟢** — `loadData()`의 HTTP/API 실패 처리, 에러 메시지 표시 및 실패 상태 전환을 확인했다.
- **T011a 🔴** — `loadData()` 성공 시의 `#lastUpdate` 갱신은 적절하지만, `refreshAllTabs()`에서 실제 데이터 성공 여부와 무관하게 `#lastUpdate`를 현재 시각으로 갱신하는 경로가 확인되었다. T012에서 수정한다.
- **T011b 🔴** — `#statusText`의 대기/로딩/완료/실패 상태 전환은 존재하지만, `refreshAllTabs()`가 `전체 탭 갱신 명령 전송됨`을 직접 출력하는 별도 경로가 있어 요구된 4개 상태 외 문구가 표시될 수 있다. T012에서 수정한다.
- **T014 🟢** — `/api/stock`에서 `EFRIEND_APPKEY`, `EFRIEND_SECRETKEY`, `EFRIEND_DOMAIN` 중 하나라도 없으면 eFriend API를 건너뛰고 `efriendStocks = []`로 반환하는 경로를 확인했다.
- **T015 🟢** — eFriend 영역에서 매매가능수량을 표시하고, 현재가 × 매매가능수량으로 매매가능금액을 계산·표시하는 구현을 확인했다.
- **T018 🔴** — `contracts/api.md`는 `/api/watchlist_groups` 응답을 `{ groups: [...] }`, `/api/watchlist_rank` 응답을 `{ items: [...] }`로 정의하지만, 현재 `server.js`는 두 API 모두 `{ success: true, data: ... }` 형태를 반환한다. 현재 `public/app.js`도 `result.data`를 사용하므로 서버만 변경하면 프론트엔드가 깨질 수 있다. T021에서 계약/구현 중 기준을 결정한 후 수정한다.
- **T019 🟢** — 관심종목 그룹 선택값이 `localStorage`의 `watchlist_selected_group`에 저장·복원되는 로직을 확인했다.
- **T020 🟢** — 관심종목 그룹 ID 직접 입력값이 드롭다운 선택값보다 우선 적용되는 로직을 확인했다.
- **T016 ⏸️** — T014~T015의 정적 검토에서는 수정 불일치를 확인하지 못했으나, 실제 eFriend 장애 시나리오 검증 전이므로 완료 처리하지 않는다.
- **T017 🟠** — eFriend 장애 시 나머지 3개 패널이 정상 동작하는지 quickstart 시나리오 4의 실제 실행이 필요하다.
- **T022 🟠** — 관심종목 그룹 변경 후 새로고침 시 선택값 유지 여부를 quickstart 시나리오 5에서 실제 확인해야 한다.
- **T023 🟠** — 현재 Feature Spec Kit 문서(spec.md/plan.md/contracts/data-model/research)와 현재 구현의 차이를 최종 비교해야 한다.
- **T024 🟠** — 장 운영 시간 외 전일 마감 데이터가 4개 패널에서 정상 표시되는지 실제 실행 검증이 필요하다.
- **T025 🟠** — 캡처 모드 중 자동 갱신 중단 구현은 확인했으나, 비활성 탭에서의 조용한 실패 처리를 포함한 최종 검증이 필요하다.
- **T026 🟠** — quickstart.md 시나리오 1~6 전체 실행 및 SC-001~004 최종 검증이 남아 있다.

### Next

- **코드 수정 보류** — 현재는 코드 수정 없이 검증 결과만 기록한다.
- **T012** — Codex 사용 가능 시 T006~T011b에서 발견된 불일치를 `server.js`, `public/app.js`에서 일괄 결정·수정한다.
- **T021** — T018에서 발견된 watchlist 계약 불일치를 T012와 함께 수정 범위를 결정한다.
- 코드 수정 후 **T013 → T017 → T022 → T023 → T024 → T025 → T026** 순서로 회귀/최종 검증한다.

---

## Dependencies & Execution Order

- **Setup (Phase 1)**: 의존성 없음 — 즉시 시작
- **Foundational (Phase 2)**: Setup 완료 후 진행 — 모든 User Story를 막는 선행 조건
- **User Stories (Phase 3~5)**: Foundational 완료 후 시작 가능. P1→P2→P3 순서 권장(우선순위 기준)이나, 서로 다른 엔드포인트를 다루므로 병렬 진행도 가능
- **Polish (Phase 6)**: 진행하고자 하는 모든 User Story 완료 후

### User Story Dependencies

- **US1 (P1)**: Foundational 이후 바로 시작 가능, 다른 스토리에 의존하지 않음
- **US2 (P2)**: Foundational 이후 바로 시작 가능, US1과 독립적(다른 엔드포인트)
- **US3 (P3)**: Foundational 이후 바로 시작 가능, US1/US2와 독립적(다른 엔드포인트)

### Parallel Opportunities

- T002는 독립적으로 병렬 가능
- T004, T005는 서로 다른 검증 대상이라 병렬 가능
- T008은 렌더링 검증이라 T006/T007(API 검증)과 병렬 가능
- US1/US2/US3는 서로 다른 엔드포인트·UI 영역을 다루므로 전체 병렬 진행 가능

---

## Implementation Strategy

### MVP First (User Story 1만)

1. Phase 1: Setup 완료
2. Phase 2: Foundational 완료 (필수)
3. Phase 3: User Story 1 완료
4. **중단 후 검증**: quickstart.md 시나리오 1~3으로 US1 독립 검증
5. 필요 시 여기까지만 배포해도 핵심 가치 제공

### Incremental Delivery

1. Setup + Foundational → 기반 확보
2. US1 추가 → 독립 검증 (MVP)
3. US2 추가 → 독립 검증
4. US3 추가 → 독립 검증
5. Polish로 마무리

## Notes

- 이 tasks.md는 신규 코드 작성이 아니라 **기존 코드의 spec 준수 여부 검증 및 수정**이 목적이다(Constitution 원칙 I).
- 검증 중 실제로 스펙과 다른 동작을 발견하면, 어느 쪽이 맞는지(코드가 맞고 spec을 고쳐야 하는지, 코드를 고쳐야 하는지) 먼저 판단한 뒤 수정한다.
- 각 태스크 완료 후 커밋 권장.